
const express = require('express');
const session = require('express-session');
const fs = require('fs');
const path = require('path');
const http = require('http');
const WebSocket = require('ws');
const nodemailer = require('nodemailer');

// ==== Nodemailer setup ====
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'msharma5639@gmail.com',
    pass: 'azdwojiwdaiqnazr'  // use .env in production!
  }
});

function sendNotificationEmail(toEmail, subject, message) {
  const mailOptions = {
    from: 'msharma5639@gmail.com',
    to: toEmail,
    subject: subject,
    text: message
  };

  transporter.sendMail(mailOptions, function (error, info) {
    if (error) {
      console.log('Error sending email:', error);
    } else {
      console.log('✅ Email sent:', info.response);
    }
  });
}

// ==== App and Server Setup ====
const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: 'secret-key',
  resave: false,
  saveUninitialized: true
}));
app.use(express.static(path.join(__dirname, 'public')));

// ==== File Storage ====
const USERS_FILE = 'users.json';
const MESSAGES_FILE = 'messages.json';

let users = [];
let messages = [];

if (fs.existsSync(USERS_FILE)) {
  users = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
}
if (fs.existsSync(MESSAGES_FILE)) {
  messages = JSON.parse(fs.readFileSync(MESSAGES_FILE, 'utf8'));
}

// ==== WebSocket Handler ====
wss.on('connection', (ws) => {
  ws.on('message', msgData => {
    const msg = JSON.parse(msgData);
    const message = {
      sender: msg.sender,
      text: msg.text,
      seen: false,
      timestamp: new Date().toISOString()
    };

    messages.push(message);
    fs.writeFileSync(MESSAGES_FILE, JSON.stringify(messages, null, 2));

    wss.clients.forEach(client => {
      if (client !== ws && client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  });
});


// ==== Express Endpoints ====

const allowedUsers = [
  { username: 'manish', password: 'pass123' },
  { username: 'friend', password: 'pass123' }
];


app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = allowedUsers.find(u => u.username === username && u.password === password);
  if (user) {
    req.session.user = username;
    res.redirect('/chat.html');
  } else {
    res.send('Login failed. <a href="/">Try again</a>');
  }
});

app.get('/session', (req, res) => {
  if (!req.session.user) return res.status(401).send('Unauthorized');
  res.json({ user: req.session.user });
});

app.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

app.get('/messages', (req, res) => {
  if (!req.session.user) return res.status(401).send('Unauthorized');
  res.json(messages);
});

app.post('/message', (req, res) => {
  if (!req.session.user) return res.status(401).send('Unauthorized');

  const sender = req.session.user;
  const text = req.body.text;
  const timestamp = new Date().toISOString();

  const msg = { sender, text, seen: false, timestamp };
  messages.push(msg);
  fs.writeFileSync(MESSAGES_FILE, JSON.stringify(messages, null, 2));

  res.sendStatus(200);
});

app.post('/seen', (req, res) => {
  if (!req.session.user) return res.status(401).send('Unauthorized');
  const currentUser = req.session.user;

  messages = messages.map(m => {
    if (m.sender !== currentUser) {
      return { ...m, seen: true };
    }
    return m;
  });

  fs.writeFileSync(MESSAGES_FILE, JSON.stringify(messages, null, 2));

  // 🔁 Broadcast seen-update to all clients
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ type: 'seen-update' }));
    }
  });

  res.sendStatus(200);
});

app.post('/seen', (req, res) => {
  if (!req.session.user) return res.status(401).send('Unauthorized');
  const currentUser = req.session.user;

  messages = messages.map(m => {
    if (m.sender !== currentUser) {
      return { ...m, seen: true };
    }
    return m;
  });

  fs.writeFileSync(MESSAGES_FILE, JSON.stringify(messages, null, 2));

  // 🔁 Broadcast update to all connected clients
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ type: 'seen-update' }));
    }
  });

  res.sendStatus(200);
});

app.post('/notify', (req, res) => {
  if (!req.session.user) return res.status(401).send('Unauthorized');
  sendNotificationEmail(
    'manishsharma.dev56@gmail.com',
    `Manual notification from ${req.session.user}`,
    `${req.session.user} is now online.`
  );
  res.send('Notification sent via email!');
});

server.listen(PORT, () => {
  console.log(`🚀 Server + WebSocket running at http://localhost:${PORT}`);
});
